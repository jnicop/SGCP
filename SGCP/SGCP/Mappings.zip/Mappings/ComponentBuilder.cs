﻿using AutoMapper;
using SGCP.DTOs.Component;
using SGCP.Models;

namespace SGCP.Mappings
{
    public class ComponentBuilderDto : Profile
    {
        public ComponentBuilderDto()
        {
            // COMPONENT BUILDER
            CreateMap<ComponentBuilderDto, Component>()
                .ForMember(dest => dest.Id, opt => opt.Ignore())
                .ForMember(dest => dest.InsertDate, opt => opt.Ignore())
                .ForMember(dest => dest.UpdateDate, opt => opt.Ignore())
                .ForMember(dest => dest.UserInsert, opt => opt.Ignore())
                .ForMember(dest => dest.UserUpdate, opt => opt.Ignore())
                .ForMember(dest => dest.Enable, opt => opt.Ignore())
                .ForMember(dest => dest.Category, opt => opt.Ignore())
                .ForMember(dest => dest.ComponentAttributes, opt => opt.Ignore())
                .ForMember(dest => dest.ComponentPresentations, opt => opt.Ignore())
                .ForMember(dest => dest.ComponentProcesses, opt => opt.Ignore())
                .ForMember(dest => dest.ComponentTreatments, opt => opt.Ignore())
                .ForMember(dest => dest.ComponentType, opt => opt.Ignore())
                .ForMember(dest => dest.ProductComponents, opt => opt.Ignore())
                .ForMember(dest => dest.ProductPackagings, opt => opt.Ignore())
                .ForMember(dest => dest.Unit, opt => opt.Ignore());

            // COMPONENT RELATED
            CreateMap<ComponentPresentationDto, ComponentPresentation>()
                .ForMember(dest => dest.Id, opt => opt.Ignore())
                .ForMember(dest => dest.ComponentId, opt => opt.Ignore())
                .ForMember(dest => dest.InsertDate, opt => opt.Ignore())
                .ForMember(dest => dest.Component, opt => opt.Ignore())
                .ForMember(dest => dest.Unit, opt => opt.Ignore());

            CreateMap<ComponentAttributeDto, ComponentAttribute>()
                .ForMember(dest => dest.Id, opt => opt.Ignore())
                .ForMember(dest => dest.ComponentId, opt => opt.Ignore())
                .ForMember(dest => dest.InsertDate, opt => opt.Ignore())
                .ForMember(dest => dest.Component, opt => opt.Ignore());

            CreateMap<ComponentTreatmentDto, ComponentTreatment>()
                .ForMember(dest => dest.Id, opt => opt.Ignore())
                .ForMember(dest => dest.ComponentId, opt => opt.Ignore())
                .ForMember(dest => dest.InsertDate, opt => opt.Ignore())
                .ForMember(dest => dest.Component, opt => opt.Ignore())
                .ForMember(dest => dest.TreatmentType, opt => opt.Ignore());

            CreateMap<ComponentProcessDto, ComponentProcess>()
                .ForMember(dest => dest.Id, opt => opt.Ignore())
                .ForMember(dest => dest.ComponentId, opt => opt.Ignore())
                .ForMember(dest => dest.TotalCost, opt => opt.Ignore())
                .ForMember(dest => dest.Component, opt => opt.Ignore())
                .ForMember(dest => dest.ProcessType, opt => opt.Ignore())
                .ForMember(dest => dest.ScopeType, opt => opt.Ignore());
        }
    
    }
}
